#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]
mod export;
mod imgops;
mod store;
mod sys;

use eframe::egui::{
    self, pos2, vec2, Align2, Color32, ColorImage, Context, FontId, Pos2, Rect, RichText, Rounding, Sense, Stroke, TextureHandle,
    TextureOptions, Ui, ViewportCommand, WindowLevel,
};
use global_hotkey::{
    hotkey::{Code, HotKey, Modifiers},
    GlobalHotKeyEvent, GlobalHotKeyManager, HotKeyState,
};
use image::RgbaImage;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::Arc;
use std::time::{Duration, Instant};

#[derive(Clone, Copy, PartialEq)]
enum Purpose {
    Capture,
    Record,
    Ocr,
    Print,
    RemoveBg,
    Vision,
}

#[derive(Clone, Copy, PartialEq)]
enum WheelAct {
    Sel(Purpose),
    Send,
    Pdf,
}

const WHEEL: [(&str, &str, WheelAct); 8] = [
    ("Screenshot", "Drag a rectangle to capture part of the screen (Enter = full screen)", WheelAct::Sel(Purpose::Capture)),
    ("Record", "Record a region of the screen to an animated GIF", WheelAct::Sel(Purpose::Record)),
    ("OCR Text", "Select an area and read the text from it (offline)", WheelAct::Sel(Purpose::Ocr)),
    ("Print Select", "Select an area and send it straight to the printer", WheelAct::Sel(Purpose::Print)),
    ("Remove BG", "Select an area and remove its plain background", WheelAct::Sel(Purpose::RemoveBg)),
    ("AI Vision", "Select an area: analysis + one-click Google Lens search", WheelAct::Sel(Purpose::Vision)),
    ("Send File", "Pick a file and send via Gmail / Outlook / Messenger", WheelAct::Send),
    ("Edit PDF", "Delete pages, rotate, merge PDFs", WheelAct::Pdf),
];

#[derive(Clone, Copy, PartialEq)]
enum Mode {
    Home,
    Wheel,
    Select(Purpose),
    Result,
    Recording,
    File,
    Pdf,
    Background,
}

#[derive(Clone, Copy, PartialEq)]
enum Center {
    Image,
    Text,
    Analysis,
}

enum Msg {
    Shot(sys::Shot),
    ShotErr(String),
    Ocr(Result<String, String>),
    RecDone(Result<PathBuf, String>),
}

struct App {
    tx: Sender<Msg>,
    rx: Receiver<Msg>,
    _manager: GlobalHotKeyManager,
    shown: Arc<AtomicBool>,
    rec_active: Arc<AtomicBool>,
    rec_stop: Arc<AtomicBool>,

    mode: Mode,
    status: String,
    shot: Option<RgbaImage>,
    shot_pos: (i32, i32),
    shot_tex: Option<TextureHandle>,
    drag_start: Option<Pos2>,
    delayed: Option<Instant>,
    bg_since: Instant,
    bg_focus_lost: bool,

    result: Option<RgbaImage>,
    result_tex: Option<TextureHandle>,
    undo: Vec<RgbaImage>,
    center: Center,
    ocr_text: String,
    ocr_busy: bool,
    sel_text: String,
    ask_prefix: String,
    analysis: Option<imgops::Analysis>,
    tol: f32,
    id_size: u32,
    id_bg: usize,
    id_outfit: usize,
    id_sheet: bool,
    store_prompt: bool,

    user: Option<String>,
    profile: store::Profile,
    login_name: String,
    login_pw: String,

    rec_started: Instant,
    screen_pts: Vec2Like,

    file_path: Option<PathBuf>,

    pdf_in: Option<PathBuf>,
    pdf_pages: usize,
    pdf_keep: String,
    pdf_rot: usize,
}

type Vec2Like = (f32, f32);

fn color_image(img: &RgbaImage) -> ColorImage {
    ColorImage::from_rgba_unmultiplied([img.width() as usize, img.height() as usize], img.as_raw())
}

fn main() -> eframe::Result<()> {
    let manager = GlobalHotKeyManager::new().expect("global hotkeys unavailable");
    let wheel_hk = HotKey::new(Some(Modifiers::SUPER | Modifiers::SHIFT), Code::KeyT);
    let stop_hk = HotKey::new(Some(Modifiers::SUPER | Modifiers::SHIFT), Code::KeyR);
    let mut hk_note = String::new();
    if manager.register(wheel_hk).is_err() {
        hk_note = "Could not register Win+Shift+T (already used by another app). Use the button on Home.".into();
    }
    let _ = manager.register(stop_hk);

    let opts = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1100.0, 740.0])
            .with_min_inner_size([160.0, 60.0])
            .with_title("Tool Wheel"),
        ..Default::default()
    };
    eframe::run_native(
        "Tool Wheel",
        opts,
        Box::new(move |cc| {
            cc.egui_ctx.set_visuals(egui::Visuals::dark());
            let (tx, rx) = channel();
            let shown = Arc::new(AtomicBool::new(true));
            let rec_active = Arc::new(AtomicBool::new(false));
            let rec_stop = Arc::new(AtomicBool::new(false));
            spawn_hotkey_thread(cc.egui_ctx.clone(), tx.clone(), wheel_hk.id(), stop_hk.id(), shown.clone(), rec_active.clone(), rec_stop.clone());
            Box::new(App {
                tx,
                rx,
                _manager: manager,
                shown,
                rec_active,
                rec_stop,
                mode: Mode::Home,
                status: if hk_note.is_empty() { "Ready. Press Win+Shift+T anywhere to open the wheel.".into() } else { hk_note },
                shot: None,
                shot_pos: (0, 0),
                shot_tex: None,
                drag_start: None,
                delayed: None,
                bg_since: Instant::now(),
                bg_focus_lost: false,
                result: None,
                result_tex: None,
                undo: vec![],
                center: Center::Image,
                ocr_text: String::new(),
                ocr_busy: false,
                sel_text: String::new(),
                ask_prefix: "Explain this text:".into(),
                analysis: None,
                tol: 40.0,
                id_size: 2,
                id_bg: 0,
                id_outfit: 0,
                id_sheet: false,
                store_prompt: false,
                user: None,
                profile: store::Profile::default(),
                login_name: String::new(),
                login_pw: String::new(),
                rec_started: Instant::now(),
                screen_pts: (1920.0, 1080.0),
                file_path: None,
                pdf_in: None,
                pdf_pages: 0,
                pdf_keep: String::new(),
                pdf_rot: 0,
            })
        }),
    )
}

fn spawn_hotkey_thread(
    ctx: Context,
    tx: Sender<Msg>,
    wheel_id: u32,
    stop_id: u32,
    shown: Arc<AtomicBool>,
    recording: Arc<AtomicBool>,
    rec_stop: Arc<AtomicBool>,
) {
    std::thread::spawn(move || {
        let rx = GlobalHotKeyEvent::receiver();
        while let Ok(ev) = rx.recv() {
            if ev.state != HotKeyState::Pressed {
                continue;
            }
            if ev.id == stop_id {
                if recording.load(Ordering::SeqCst) {
                    rec_stop.store(true, Ordering::SeqCst);
                }
                ctx.request_repaint();
                continue;
            }
            if ev.id == wheel_id {
                if recording.load(Ordering::SeqCst) {
                    continue;
                }
                if shown.load(Ordering::SeqCst) {
                    ctx.send_viewport_cmd(ViewportCommand::OuterPosition(pos2(-4000.0, -4000.0)));
                    ctx.request_repaint();
                    std::thread::sleep(Duration::from_millis(450));
                }
                let _ = match sys::capture_primary() {
                    Ok(s) => tx.send(Msg::Shot(s)),
                    Err(e) => tx.send(Msg::ShotErr(e)),
                };
                ctx.request_repaint();
            }
        }
    });
}

// ---------- window helpers ----------

fn go_overlay(ctx: &Context, w: u32, h: u32, x: i32, y: i32) {
    let ppp = ctx.pixels_per_point();
    ctx.send_viewport_cmd(ViewportCommand::Decorations(false));
    ctx.send_viewport_cmd(ViewportCommand::WindowLevel(WindowLevel::AlwaysOnTop));
    ctx.send_viewport_cmd(ViewportCommand::OuterPosition(pos2(x as f32 / ppp, y as f32 / ppp)));
    ctx.send_viewport_cmd(ViewportCommand::InnerSize(vec2(w as f32 / ppp, h as f32 / ppp)));
    ctx.send_viewport_cmd(ViewportCommand::Focus);
}

fn go_normal(ctx: &Context) {
    ctx.send_viewport_cmd(ViewportCommand::WindowLevel(WindowLevel::Normal));
    ctx.send_viewport_cmd(ViewportCommand::Decorations(true));
    ctx.send_viewport_cmd(ViewportCommand::InnerSize(vec2(1100.0, 740.0)));
    ctx.send_viewport_cmd(ViewportCommand::OuterPosition(pos2(80.0, 40.0)));
    ctx.send_viewport_cmd(ViewportCommand::Focus);
}

fn go_off_screen(ctx: &Context) {
    ctx.send_viewport_cmd(ViewportCommand::WindowLevel(WindowLevel::Normal));
    ctx.send_viewport_cmd(ViewportCommand::InnerSize(vec2(160.0, 60.0)));
    ctx.send_viewport_cmd(ViewportCommand::OuterPosition(pos2(-4000.0, -4000.0)));
}

fn checker(p: &egui::Painter, rect: Rect) {
    let t = 12.0;
    p.rect_filled(rect, Rounding::ZERO, Color32::from_gray(70));
    let mut y = 0;
    let mut yy = rect.top();
    while yy < rect.bottom() {
        let mut xx = rect.left();
        let mut x = 0;
        while xx < rect.right() {
            if (x + y) % 2 == 0 {
                let r = Rect::from_min_max(pos2(xx, yy), pos2((xx + t).min(rect.right()), (yy + t).min(rect.bottom())));
                p.rect_filled(r, Rounding::ZERO, Color32::from_gray(95));
            }
            xx += t;
            x += 1;
        }
        yy += t;
        y += 1;
    }
}

fn show_image(ui: &mut Ui, tex: &TextureHandle) {
    let avail = ui.available_size();
    let sz = tex.size_vec2();
    let scale = (avail.x / sz.x).min(avail.y / sz.y).clamp(0.01, 3.0);
    let (rect, _) = ui.allocate_exact_size(sz * scale, Sense::hover());
    checker(ui.painter(), rect);
    ui.painter().image(tex.id(), rect, Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0)), Color32::WHITE);
}

fn parse_pages(s: &str, max: u32) -> Vec<u32> {
    let mut v = vec![];
    for part in s.split(',') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        if let Some((a, b)) = part.split_once('-') {
            if let (Ok(a), Ok(b)) = (a.trim().parse::<u32>(), b.trim().parse::<u32>()) {
                for p in a..=b {
                    if p >= 1 && p <= max && !v.contains(&p) {
                        v.push(p);
                    }
                }
            }
        } else if let Ok(p) = part.parse::<u32>() {
            if p >= 1 && p <= max && !v.contains(&p) {
                v.push(p);
            }
        }
    }
    v.sort();
    v
}

impl App {
    // ----- state helpers -----
    fn set_result(&mut self, ctx: &Context, img: RgbaImage) {
        self.result_tex = Some(ctx.load_texture("result", color_image(&img), TextureOptions::LINEAR));
        self.result = Some(img);
    }

    fn push_undo(&mut self) {
        if let Some(r) = &self.result {
            self.undo.push(r.clone());
            if self.undo.len() > 10 {
                self.undo.remove(0);
            }
        }
    }

    fn new_result(&mut self, ctx: &Context, img: RgbaImage, center: Center) {
        self.undo.clear();
        self.ocr_text.clear();
        self.analysis = None;
        self.sel_text.clear();
        self.center = center;
        self.set_result(ctx, img);
    }

    fn start_ocr(&mut self, ctx: &Context) {
        if let Some(img) = self.result.clone() {
            self.ocr_busy = true;
            self.status = "Reading text...".into();
            let tx = self.tx.clone();
            let c = ctx.clone();
            std::thread::spawn(move || {
                let _ = tx.send(Msg::Ocr(sys::ocr_image(&img)));
                c.request_repaint();
            });
        }
    }

    fn temp_png(&self, name: &str) -> Option<PathBuf> {
        let img = self.result.as_ref()?;
        let p = store::exports_dir().join(format!("{}_{}.png", name, chrono::Local::now().format("%Y%m%d_%H%M%S")));
        export::save_image(img, &p).ok()?;
        Some(p)
    }

    fn store_result(&mut self) {
        let Some(user) = self.user.clone() else {
            self.status = "Sign in on the Home screen to use storage.".into();
            return;
        };
        let Some(img) = &self.result else { return };
        match store::store_item(&user, "Image", "png", &export::png_bytes(img)) {
            Ok(c) => {
                self.profile = store::profile(&user);
                self.status = format!("Saved to storage. +{} clouds!", c);
            }
            Err(e) => self.status = format!("Storage error: {}", e),
        }
    }

    fn open_wheel_from_app(&mut self, ctx: &Context) {
        go_off_screen(ctx);
        self.shown.store(false, Ordering::SeqCst);
        self.mode = Mode::Background;
        self.bg_since = Instant::now();
        self.bg_focus_lost = false;
        self.delayed = Some(Instant::now() + Duration::from_millis(500));
    }

    fn enter_wheel(&mut self, ctx: &Context, s: sys::Shot) {
        let (w, h) = s.img.dimensions();
        self.shot_tex = Some(ctx.load_texture("shot", color_image(&s.img), TextureOptions::LINEAR));
        self.shot = Some(s.img);
        self.shot_pos = (s.x, s.y);
        self.screen_pts = (w as f32 / ctx.pixels_per_point(), h as f32 / ctx.pixels_per_point());
        self.mode = Mode::Wheel;
        self.shown.store(true, Ordering::SeqCst);
        go_overlay(ctx, w, h, s.x, s.y);
    }

    fn to_background(&mut self, ctx: &Context) {
        self.shot = None;
        self.shot_tex = None;
        self.drag_start = None;
        go_off_screen(ctx);
        self.shown.store(false, Ordering::SeqCst);
        self.mode = Mode::Background;
        self.bg_since = Instant::now();
        self.bg_focus_lost = false;
    }

    fn to_normal(&mut self, ctx: &Context, mode: Mode) {
        self.shot = None;
        self.shot_tex = None;
        self.mode = mode;
        self.shown.store(true, Ordering::SeqCst);
        go_normal(ctx);
    }

    fn finish_select(&mut self, ctx: &Context, p: Purpose, x: u32, y: u32, w: u32, h: u32) {
        let Some(shot) = self.shot.clone() else { return };
        let img = imgops::crop(&shot, x, y, w, h);
        match p {
            Purpose::Capture => {
                self.new_result(ctx, img, Center::Image);
                self.store_prompt = true;
                self.status = format!("Captured {}x{}", w, h);
                self.to_normal(ctx, Mode::Result);
            }
            Purpose::Ocr => {
                self.new_result(ctx, img, Center::Text);
                self.start_ocr(ctx);
                self.to_normal(ctx, Mode::Result);
            }
            Purpose::Print => {
                self.new_result(ctx, img, Center::Image);
                self.to_normal(ctx, Mode::Result);
                self.print_result();
            }
            Purpose::RemoveBg => {
                let out = imgops::remove_background(&img, self.tol);
                self.new_result(ctx, out, Center::Image);
                self.store_prompt = true;
                self.status = "Background removed. Adjust tolerance in the side panel if needed.".into();
                self.to_normal(ctx, Mode::Result);
            }
            Purpose::Vision => {
                let a = imgops::analyze(&img);
                self.new_result(ctx, img, Center::Analysis);
                self.analysis = Some(a);
                self.start_ocr(ctx);
                self.to_normal(ctx, Mode::Result);
            }
            Purpose::Record => self.start_recording(ctx, x, y, w, h),
        }
    }

    fn print_result(&mut self) {
        if let Some(p) = self.temp_png("print") {
            self.status = match sys::print_file(&p) {
                Ok(_) => "Sent to printer / print dialog opened.".into(),
                Err(e) => format!("Print failed: {}", e),
            };
        }
    }

    fn start_recording(&mut self, ctx: &Context, x: u32, y: u32, w: u32, h: u32) {
        self.rec_stop.store(false, Ordering::SeqCst);
        self.rec_active.store(true, Ordering::SeqCst);
        self.rec_started = Instant::now();
        let stop = self.rec_stop.clone();
        let active = self.rec_active.clone();
        let tx = self.tx.clone();
        let c = ctx.clone();
        std::thread::spawn(move || {
            let mut frames: Vec<RgbaImage> = vec![];
            let t0 = Instant::now();
            std::thread::sleep(Duration::from_millis(600));
            while !stop.load(Ordering::SeqCst) && frames.len() < 400 {
                let f0 = Instant::now();
                if let Ok(s) = sys::capture_primary() {
                    let mut c2 = imgops::crop(&s.img, x, y, w, h);
                    if c2.width() > 640 {
                        let nw = 640;
                        let nh = ((c2.height() as f32) * 640.0 / c2.width() as f32).max(1.0) as u32;
                        c2 = image::imageops::resize(&c2, nw, nh, image::imageops::FilterType::Triangle);
                    }
                    frames.push(c2);
                }
                let el = f0.elapsed();
                if el < Duration::from_millis(125) {
                    std::thread::sleep(Duration::from_millis(125) - el);
                }
            }
            active.store(false, Ordering::SeqCst);
            let path = store::exports_dir().join(format!("recording_{}.gif", chrono::Local::now().format("%Y%m%d_%H%M%S")));
            let delay = if frames.is_empty() { 125 } else { ((t0.elapsed().as_millis() / frames.len() as u128).max(60)) as u32 };
            let res = if frames.is_empty() { Err("No frames captured".to_string()) } else { export::save_gif(frames, delay, &path).map(|_| path) };
            let _ = tx.send(Msg::RecDone(res));
            c.request_repaint();
        });
        self.shot = None;
        self.shot_tex = None;
        self.mode = Mode::Recording;
        self.shown.store(true, Ordering::SeqCst);
        let ppp = ctx.pixels_per_point();
        let (_sw, _) = (self.screen_pts.0, ppp);
        ctx.send_viewport_cmd(ViewportCommand::WindowLevel(WindowLevel::AlwaysOnTop));
        ctx.send_viewport_cmd(ViewportCommand::Decorations(true));
        ctx.send_viewport_cmd(ViewportCommand::InnerSize(vec2(260.0, 110.0)));
        ctx.send_viewport_cmd(ViewportCommand::OuterPosition(pos2((self.screen_pts.0 - 290.0).max(0.0), 20.0)));
    }

    fn send_via(&mut self, which: &str, path: &PathBuf, copy_img: bool) {
        if copy_img {
            if let Some(img) = &self.result {
                let _ = sys::copy_image_to_clipboard(img);
            }
        }
        let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
        let url = match which {
            "gmail" => format!("https://mail.google.com/mail/?view=cm&fs=1&su={}", sys::url_encode(&name)),
            "outlook" => format!("https://outlook.live.com/mail/0/deeplink/compose?subject={}", sys::url_encode(&name)),
            "messenger" => "https://www.messenger.com/".to_string(),
            _ => format!("mailto:?subject={}", sys::url_encode(&name)),
        };
        let _ = open::that(url);
        sys::reveal(path);
        self.status = if copy_img {
            "Image copied: press Ctrl+V in the message, or drag the highlighted file in.".into()
        } else {
            "Drag the highlighted file into the message to attach it.".into()
        };
    }

    fn send_panel(&mut self, ui: &mut Ui, path: Option<PathBuf>, copy_img: bool) {
        let Some(path) = path else {
            ui.label("Could not prepare the file.");
            return;
        };
        ui.label(RichText::new(path.to_string_lossy()).small());
        ui.horizontal_wrapped(|ui| {
            if ui.button("Gmail").clicked() {
                self.send_via("gmail", &path, copy_img);
            }
            if ui.button("Outlook").clicked() {
                self.send_via("outlook", &path, copy_img);
            }
            if ui.button("Messenger").clicked() {
                self.send_via("messenger", &path, copy_img);
            }
            if ui.button("Email app").clicked() {
                self.send_via("mailto", &path, copy_img);
            }
        });
    }

    // ----- message pump -----
    fn pump(&mut self, ctx: &Context) {
        while let Ok(m) = self.rx.try_recv() {
            match m {
                Msg::Shot(s) => {
                    if self.mode != Mode::Recording {
                        self.enter_wheel(ctx, s);
                    }
                }
                Msg::ShotErr(e) => {
                    self.status = format!("Screen capture failed: {}", e);
                    self.to_normal(ctx, Mode::Home);
                }
                Msg::Ocr(r) => {
                    self.ocr_busy = false;
                    match r {
                        Ok(t) => {
                            self.status = if t.trim().is_empty() { "No text found in this image.".into() } else { "Text ready. Highlight a part to ask AI about it.".into() };
                            self.ocr_text = t;
                        }
                        Err(e) => self.status = format!("OCR error: {}", e),
                    }
                }
                Msg::RecDone(r) => {
                    match r {
                        Ok(p) => {
                            self.status = "Recording saved.".into();
                            self.file_path = Some(p);
                            self.to_normal(ctx, Mode::File);
                        }
                        Err(e) => {
                            self.status = format!("Recording failed: {}", e);
                            self.to_normal(ctx, Mode::Home);
                        }
                    }
                }
            }
        }
        if let Some(t) = self.delayed {
            if Instant::now() >= t {
                self.delayed = None;
                match sys::capture_primary() {
                    Ok(s) => self.enter_wheel(ctx, s),
                    Err(e) => {
                        self.status = format!("Screen capture failed: {}", e);
                        self.to_normal(ctx, Mode::Home);
                    }
                }
            }
        }
    }
}

impl eframe::App for App {
    fn update(&mut self, ctx: &Context, _frame: &mut eframe::Frame) {
        self.pump(ctx);

        if self.mode == Mode::Background {
            ctx.request_repaint_after(Duration::from_millis(200));
            let focused = ctx.input(|i| i.viewport().focused).unwrap_or(false);
            if !focused {
                self.bg_focus_lost = true;
            }
            if focused && self.bg_focus_lost && self.delayed.is_none() && self.bg_since.elapsed() > Duration::from_millis(800) {
                self.to_normal(ctx, Mode::Home);
            }
            egui::CentralPanel::default().show(ctx, |ui| {
                ui.label("Tool Wheel running...");
            });
            return;
        }

        match self.mode {
            Mode::Wheel => self.ui_wheel(ctx),
            Mode::Select(p) => self.ui_select(ctx, p),
            Mode::Recording => self.ui_recording(ctx),
            _ => self.ui_normal(ctx),
        }
        if self.mode == Mode::Recording || self.ocr_busy {
            ctx.request_repaint_after(Duration::from_millis(250));
        }
    }
}

impl App {
    // ---------- wheel ----------
    fn ui_wheel(&mut self, ctx: &Context) {
        let mut next: Option<WheelAct> = None;
        let mut home = false;
        let mut cancel = false;
        egui::CentralPanel::default().frame(egui::Frame::none()).show(ctx, |ui| {
            let rect = ui.max_rect();
            let painter = ui.painter();
            if let Some(t) = &self.shot_tex {
                painter.image(t.id(), rect, Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0)), Color32::WHITE);
            }
            painter.rect_filled(rect, Rounding::ZERO, Color32::from_black_alpha(150));
            let c = rect.center();
            let outer = (rect.height().min(rect.width()) * 0.32).min(260.0);
            let inner = outer * 0.36;
            let hover = ctx.input(|i| i.pointer.hover_pos());
            let mut hovered: Option<usize> = None;
            let mut center_hover = false;
            if let Some(p) = hover {
                let d = p - c;
                let dist = d.length();
                if dist < inner {
                    center_hover = true;
                } else if dist < outer * 1.05 {
                    let ang = d.y.atan2(d.x).to_degrees();
                    let idx = (((ang + 90.0 + 22.5).rem_euclid(360.0)) / 45.0) as usize % 8;
                    hovered = Some(idx);
                }
            }
            for (i, (label, _, _)) in WHEEL.iter().enumerate() {
                let a0 = (-90.0 - 22.5 + i as f32 * 45.0 + 1.2).to_radians();
                let a1 = (-90.0 - 22.5 + (i + 1) as f32 * 45.0 - 1.2).to_radians();
                let is_h = hovered == Some(i);
                let ro = if is_h { outer * 1.06 } else { outer };
                let col = if is_h { Color32::from_rgb(235, 140, 30) } else { Color32::from_rgba_unmultiplied(28, 30, 38, 235) };
                let mut mesh = egui::Mesh::default();
                let steps = 14;
                for s in 0..=steps {
                    let a = a0 + (a1 - a0) * s as f32 / steps as f32;
                    let (sn, cs) = a.sin_cos();
                    mesh.colored_vertex(c + vec2(cs, sn) * inner, col);
                    mesh.colored_vertex(c + vec2(cs, sn) * ro, col);
                }
                for s in 0..steps as u32 {
                    let b = s * 2;
                    mesh.add_triangle(b, b + 1, b + 2);
                    mesh.add_triangle(b + 1, b + 3, b + 2);
                }
                painter.add(egui::Shape::mesh(mesh));
                let am = (a0 + a1) / 2.0;
                let lp = c + vec2(am.cos(), am.sin()) * ((inner + outer) / 2.0 + 4.0);
                painter.text(lp, Align2::CENTER_CENTER, format!("{}\n{}", i + 1, label), FontId::proportional(16.0), Color32::WHITE);
            }
            let ccol = if center_hover { Color32::from_rgb(60, 130, 220) } else { Color32::from_rgb(40, 44, 56) };
            painter.circle_filled(c, inner * 0.92, ccol);
            painter.text(c, Align2::CENTER_CENTER, "Home", FontId::proportional(17.0), Color32::WHITE);
            let hint = match hovered {
                Some(i) => WHEEL[i].1,
                None if center_hover => "Open the Tool Wheel app window (history, sign in...)",
                None => "Click a tool, press 1-8, or Esc to close",
            };
            painter.text(pos2(c.x, c.y + outer + 50.0), Align2::CENTER_CENTER, hint, FontId::proportional(18.0), Color32::WHITE);

            let clicked = ctx.input(|i| i.pointer.primary_clicked());
            if clicked {
                if let Some(i) = hovered {
                    next = Some(WHEEL[i].2);
                } else if center_hover {
                    home = true;
                }
            }
            for (i, key) in [egui::Key::Num1, egui::Key::Num2, egui::Key::Num3, egui::Key::Num4, egui::Key::Num5, egui::Key::Num6, egui::Key::Num7, egui::Key::Num8].iter().enumerate() {
                if ctx.input(|inp| inp.key_pressed(*key)) {
                    next = Some(WHEEL[i].2);
                }
            }
            if ctx.input(|i| i.key_pressed(egui::Key::Escape)) {
                cancel = true;
            }
        });
        if cancel {
            self.to_background(ctx);
        } else if home {
            self.to_normal(ctx, Mode::Home);
        } else if let Some(a) = next {
            match a {
                WheelAct::Sel(p) => {
                    self.mode = Mode::Select(p);
                    self.drag_start = None;
                }
                WheelAct::Send => {
                    self.to_normal(ctx, Mode::File);
                    if let Some(p) = rfd::FileDialog::new().set_title("Pick a file to send").pick_file() {
                        self.file_path = Some(p);
                    } else {
                        self.mode = Mode::Home;
                    }
                }
                WheelAct::Pdf => {
                    self.to_normal(ctx, Mode::Pdf);
                }
            }
        }
    }

    // ---------- region selection ----------
    fn ui_select(&mut self, ctx: &Context, p: Purpose) {
        let mut done: Option<(u32, u32, u32, u32)> = None;
        let mut cancel = false;
        egui::CentralPanel::default().frame(egui::Frame::none()).show(ctx, |ui| {
            let rect = ui.max_rect();
            let (iw, ih) = self.shot.as_ref().map(|s| s.dimensions()).unwrap_or((1, 1));
            let sx = iw as f32 / rect.width();
            let sy = ih as f32 / rect.height();
            let painter = ui.painter();
            if let Some(t) = &self.shot_tex {
                painter.image(t.id(), rect, Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0)), Color32::WHITE);
            }
            painter.rect_filled(rect, Rounding::ZERO, Color32::from_black_alpha(110));
            ctx.set_cursor_icon(egui::CursorIcon::Crosshair);
            let (pressed, released, pos) = ctx.input(|i| (i.pointer.primary_pressed(), i.pointer.primary_released(), i.pointer.interact_pos()));
            if pressed {
                self.drag_start = pos;
            }
            if let (Some(a), Some(b)) = (self.drag_start, pos) {
                let sel = Rect::from_two_pos(a, b).intersect(rect);
                // bright (un-dimmed) selection
                let uv = Rect::from_min_max(
                    pos2((sel.left() - rect.left()) / rect.width(), (sel.top() - rect.top()) / rect.height()),
                    pos2((sel.right() - rect.left()) / rect.width(), (sel.bottom() - rect.top()) / rect.height()),
                );
                if let Some(t) = &self.shot_tex {
                    painter.image(t.id(), sel, uv, Color32::WHITE);
                }
                painter.rect_stroke(sel, Rounding::ZERO, Stroke::new(2.0_f32, Color32::from_rgb(235, 140, 30)));
                painter.text(sel.left_top() + vec2(4.0, -14.0), Align2::LEFT_CENTER, format!("{} x {}", (sel.width() * sx) as u32, (sel.height() * sy) as u32), FontId::proportional(14.0), Color32::WHITE);
                if released {
                    if sel.width() > 6.0 && sel.height() > 6.0 {
                        done = Some((((sel.left() - rect.left()) * sx) as u32, ((sel.top() - rect.top()) * sy) as u32, (sel.width() * sx) as u32, (sel.height() * sy) as u32));
                    }
                    self.drag_start = None;
                }
            }
            let msg = match p {
                Purpose::Record => "Drag the area to RECORD  -  Enter = whole screen  -  Esc = cancel",
                _ => "Drag to select an area  -  Enter = whole screen  -  Esc = cancel",
            };
            painter.text(pos2(rect.center().x, 36.0), Align2::CENTER_CENTER, msg, FontId::proportional(20.0), Color32::WHITE);
            if ctx.input(|i| i.key_pressed(egui::Key::Enter)) {
                done = Some((0, 0, iw, ih));
            }
            if ctx.input(|i| i.key_pressed(egui::Key::Escape)) {
                cancel = true;
            }
        });
        if cancel {
            self.to_background(ctx);
        } else if let Some((x, y, w, h)) = done {
            self.finish_select(ctx, p, x, y, w, h);
        }
    }

    // ---------- recording mini window ----------
    fn ui_recording(&mut self, ctx: &Context) {
        egui::CentralPanel::default().show(ctx, |ui| {
            let secs = self.rec_started.elapsed().as_secs();
            ui.label(RichText::new(format!("REC  {:02}:{:02}", secs / 60, secs % 60)).color(Color32::from_rgb(240, 70, 70)).size(22.0).strong());
            if ui.button("Stop recording").clicked() {
                self.rec_stop.store(true, Ordering::SeqCst);
                self.status = "Saving recording...".into();
            }
            ui.label(RichText::new("or press Win+Shift+R").small());
            if self.rec_stop.load(Ordering::SeqCst) {
                ui.label("Encoding GIF...");
            }
        });
    }
}

// ---------- normal window screens ----------
impl App {
    fn ui_normal(&mut self, ctx: &Context) {
        // in-app shortcut
        if ctx.input(|i| i.modifiers.ctrl && i.key_pressed(egui::Key::T)) {
            self.open_wheel_from_app(ctx);
            return;
        }

        egui::TopBottomPanel::top("top").show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.heading("Tool Wheel");
                ui.separator();
                if ui.button("Home").clicked() {
                    self.mode = Mode::Home;
                }
                if ui.button("Open Wheel (Win+Shift+T / Ctrl+T)").clicked() {
                    self.open_wheel_from_app(ctx);
                }
                if ui.button("Edit PDF").clicked() {
                    self.mode = Mode::Pdf;
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if let Some(u) = &self.user {
                        ui.label(format!("{}  |  Clouds: {}", u, self.profile.clouds));
                    } else {
                        ui.label("Not signed in");
                    }
                });
            });
        });
        egui::TopBottomPanel::bottom("status").show(ctx, |ui| {
            ui.label(&self.status);
        });

        // "save to storage?" prompt
        if self.store_prompt {
            egui::Window::new("Save to storage?")
                .collapsible(false)
                .resizable(false)
                .anchor(Align2::CENTER_CENTER, vec2(0.0, 0.0))
                .show(ctx, |ui| {
                    ui.label("Store this result in your cloud storage and earn clouds?");
                    ui.horizontal(|ui| {
                        if ui.button("Yes, save").clicked() {
                            self.store_prompt = false;
                            self.store_result();
                        }
                        if ui.button("No").clicked() {
                            self.store_prompt = false;
                        }
                    });
                });
        }

        match self.mode {
            Mode::Result => self.ui_result(ctx),
            Mode::File => self.ui_file(ctx),
            Mode::Pdf => self.ui_pdf(ctx),
            _ => self.ui_home(ctx),
        }
    }

    fn ui_home(&mut self, ctx: &Context) {
        egui::CentralPanel::default().show(ctx, |ui| {
            egui::ScrollArea::vertical().show(ui, |ui| {
                ui.add_space(6.0);
                ui.label(RichText::new("Press Win+Shift+T anywhere to open the tool wheel. Close this window to quit; press Esc on the wheel to send the app to the background.").weak());
                ui.add_space(8.0);
                ui.horizontal_wrapped(|ui| {
                    if ui.add(egui::Button::new(RichText::new("Open Tool Wheel").size(18.0)).min_size(vec2(220.0, 44.0))).clicked() {
                        self.open_wheel_from_app(ctx);
                    }
                    if ui.add(egui::Button::new("Open image file...").min_size(vec2(160.0, 44.0))).clicked() {
                        if let Some(p) = rfd::FileDialog::new().add_filter("Images", &["png", "jpg", "jpeg", "gif", "bmp", "webp"]).pick_file() {
                            match image::open(&p) {
                                Ok(i) => {
                                    self.new_result(ctx, i.to_rgba8(), Center::Image);
                                    self.mode = Mode::Result;
                                    self.status = "Image loaded.".into();
                                }
                                Err(e) => self.status = format!("Could not open image: {}", e),
                            }
                        }
                    }
                    if ui.add(egui::Button::new("Send a file...").min_size(vec2(140.0, 44.0))).clicked() {
                        if let Some(p) = rfd::FileDialog::new().pick_file() {
                            self.file_path = Some(p);
                            self.mode = Mode::File;
                        }
                    }
                });
                ui.add_space(14.0);
                ui.separator();
                ui.heading("Account & history");
                if self.user.is_none() {
                    ui.horizontal(|ui| {
                        ui.label("Username");
                        ui.text_edit_singleline(&mut self.login_name);
                        ui.label("Password");
                        ui.add(egui::TextEdit::singleline(&mut self.login_pw).password(true));
                        if ui.button("Sign in").clicked() {
                            match store::login(self.login_name.trim(), &self.login_pw) {
                                Ok(_) => {
                                    let n = self.login_name.trim().to_string();
                                    self.profile = store::profile(&n);
                                    self.status = format!("Welcome back, {}!", n);
                                    self.user = Some(n);
                                    self.login_pw.clear();
                                }
                                Err(e) => self.status = e,
                            }
                        }
                        if ui.button("Register").clicked() {
                            match store::register(self.login_name.trim(), &self.login_pw) {
                                Ok(_) => {
                                    let n = self.login_name.trim().to_string();
                                    self.profile = store::profile(&n);
                                    self.status = format!("Account created. Welcome, {}!", n);
                                    self.user = Some(n);
                                    self.login_pw.clear();
                                }
                                Err(e) => self.status = e,
                            }
                        }
                    });
                    ui.label(RichText::new("Accounts and storage are saved locally on this PC (Documents/ToolWheel).").small().weak());
                } else {
                    let user = self.user.clone().unwrap();
                    ui.horizontal(|ui| {
                        ui.label(RichText::new(format!("Signed in as {}   |   Clouds earned: {}", user, self.profile.clouds)).strong());
                        if ui.button("Sign out").clicked() {
                            self.user = None;
                            self.profile = store::Profile::default();
                        }
                        if ui.button("Open storage folder").clicked() {
                            let _ = open::that(store::base().join("storage").join(&user));
                        }
                    });
                    ui.add_space(6.0);
                    if self.profile.entries.is_empty() {
                        ui.label("No saved items yet. After a screenshot or background removal you will be asked to store it.");
                    }
                    let entries: Vec<store::Entry> = self.profile.entries.iter().rev().cloned().collect();
                    let mut delete: Option<u64> = None;
                    for e in entries {
                        ui.horizontal(|ui| {
                            ui.label(format!("#{}  {}  -  {}  ({} KB)", e.id, e.label, e.when, e.bytes / 1024));
                            let path = store::entry_path(&user, &e);
                            if ui.button("Open").clicked() {
                                let _ = open::that(&path);
                            }
                            if ui.button("Load in editor").clicked() {
                                match image::open(&path) {
                                    Ok(i) => {
                                        self.new_result(ctx, i.to_rgba8(), Center::Image);
                                        self.mode = Mode::Result;
                                    }
                                    Err(err) => self.status = format!("Not an image: {}", err),
                                }
                            }
                            if ui.button("Delete").clicked() {
                                delete = Some(e.id);
                            }
                        });
                    }
                    if let Some(id) = delete {
                        store::delete_item(&user, id);
                        self.profile = store::profile(&user);
                    }
                }
            });
        });
    }

    fn ui_file(&mut self, ctx: &Context) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("File");
            let Some(path) = self.file_path.clone() else {
                ui.label("No file chosen.");
                if ui.button("Pick a file...").clicked() {
                    self.file_path = rfd::FileDialog::new().pick_file();
                }
                return;
            };
            ui.label(path.to_string_lossy());
            ui.horizontal(|ui| {
                if ui.button("Open").clicked() {
                    let _ = open::that(&path);
                }
                if ui.button("Show in folder").clicked() {
                    sys::reveal(&path);
                }
                if ui.button("Choose another...").clicked() {
                    if let Some(p) = rfd::FileDialog::new().pick_file() {
                        self.file_path = Some(p);
                    }
                }
            });
            ui.add_space(10.0);
            ui.label(RichText::new("Send via").strong());
            self.send_panel(ui, Some(path.clone()), false);
            ui.add_space(10.0);
            ui.label(RichText::new("Export / store").strong());
            ui.horizontal(|ui| {
                if ui.button("Zip this file").clicked() {
                    let zp = path.with_extension("zip");
                    let res = (|| -> Result<(), String> {
                        let bytes = std::fs::read(&path).map_err(|e| e.to_string())?;
                        let f = std::fs::File::create(&zp).map_err(|e| e.to_string())?;
                        let mut z = zip::ZipWriter::new(f);
                        let name = path.file_name().unwrap_or_default().to_string_lossy().to_string();
                        z.start_file(name, zip::write::FileOptions::default().compression_method(zip::CompressionMethod::Deflated)).map_err(|e| e.to_string())?;
                        std::io::Write::write_all(&mut z, &bytes).map_err(|e| e.to_string())?;
                        z.finish().map_err(|e| e.to_string())?;
                        Ok(())
                    })();
                    self.status = match res {
                        Ok(_) => format!("Zipped to {}", zp.display()),
                        Err(e) => format!("Zip failed: {}", e),
                    };
                    if res_ok(&self.status) {
                        self.file_path = Some(zp);
                    }
                }
                if ui.button("Save to storage").clicked() {
                    match (&self.user, std::fs::read(&path)) {
                        (Some(u), Ok(bytes)) => {
                            let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("bin").to_string();
                            let label = path.file_name().unwrap_or_default().to_string_lossy().to_string();
                            match store::store_item(u, &label, &ext, &bytes) {
                                Ok(c) => {
                                    self.profile = store::profile(u);
                                    self.status = format!("Saved to storage. +{} clouds!", c);
                                }
                                Err(e) => self.status = e,
                            }
                        }
                        (None, _) => self.status = "Sign in on Home to use storage.".into(),
                        (_, Err(e)) => self.status = e.to_string(),
                    }
                }
            });
        });
    }

    fn ui_pdf(&mut self, ctx: &Context) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("Edit PDF");
            ui.label("Delete pages, extract pages, rotate, or merge another PDF at the end.");
            ui.add_space(8.0);
            if ui.button("Open PDF...").clicked() {
                if let Some(p) = rfd::FileDialog::new().add_filter("PDF", &["pdf"]).pick_file() {
                    match export::pdf_page_count(&p) {
                        Ok(n) => {
                            self.pdf_pages = n;
                            self.pdf_keep = if n > 1 { format!("1-{}", n) } else { "1".into() };
                            self.pdf_in = Some(p);
                            self.status = format!("Loaded PDF with {} pages.", n);
                        }
                        Err(e) => self.status = format!("Could not read PDF: {}", e),
                    }
                }
            }
            let Some(input) = self.pdf_in.clone() else { return };
            ui.label(input.to_string_lossy());
            ui.label(format!("Pages: {}", self.pdf_pages));
            ui.horizontal(|ui| {
                ui.label("Pages to keep (e.g. 1-3,5):");
                ui.text_edit_singleline(&mut self.pdf_keep);
            });
            egui::ComboBox::from_label("Rotate kept pages").selected_text(["None", "90 clockwise", "180", "90 counter-clockwise"][self.pdf_rot]).show_ui(ui, |ui| {
                for (i, n) in ["None", "90 clockwise", "180", "90 counter-clockwise"].iter().enumerate() {
                    ui.selectable_value(&mut self.pdf_rot, i, *n);
                }
            });
            ui.horizontal(|ui| {
                if ui.button("Save edited PDF...").clicked() {
                    let keep = parse_pages(&self.pdf_keep, self.pdf_pages as u32);
                    if keep.is_empty() {
                        self.status = "No valid pages selected.".into();
                    } else if let Some(out) = rfd::FileDialog::new().add_filter("PDF", &["pdf"]).set_file_name("edited.pdf").save_file() {
                        let rot = [0, 90, 180, 270][self.pdf_rot];
                        match export::pdf_edit(&input, &out, &keep, rot) {
                            Ok(_) => {
                                self.status = format!("Saved {}", out.display());
                                let _ = open::that(&out);
                            }
                            Err(e) => self.status = format!("Edit failed: {}", e),
                        }
                    }
                }
                if ui.button("Merge another PDF at end...").clicked() {
                    if let Some(other) = rfd::FileDialog::new().add_filter("PDF", &["pdf"]).pick_file() {
                        if let Some(out) = rfd::FileDialog::new().add_filter("PDF", &["pdf"]).set_file_name("merged.pdf").save_file() {
                            match export::pdf_merge(&input, &other, &out) {
                                Ok(_) => {
                                    self.status = format!("Merged into {}", out.display());
                                    let _ = open::that(&out);
                                }
                                Err(e) => self.status = format!("Merge failed: {}", e),
                            }
                        }
                    }
                }
            });
        });
    }

    fn ui_result(&mut self, ctx: &Context) {
        egui::SidePanel::right("tools").exact_width(310.0).show(ctx, |ui| {
            egui::ScrollArea::vertical().show(ui, |ui| {
                ui.add_space(4.0);
                ui.horizontal_wrapped(|ui| {
                    if ui.button("Copy image").clicked() {
                        if let Some(i) = &self.result {
                            self.status = match sys::copy_image_to_clipboard(i) {
                                Ok(_) => "Image copied to clipboard.".into(),
                                Err(e) => format!("Clipboard error: {}", e),
                            };
                        }
                    }
                    if ui.button("Save as...").clicked() {
                        if let Some(p) = rfd::FileDialog::new().add_filter("PNG", &["png"]).add_filter("JPEG", &["jpg"]).set_file_name("image.png").save_file() {
                            if let Some(i) = &self.result {
                                self.status = match export::save_image(i, &p) {
                                    Ok(_) => format!("Saved {}", p.display()),
                                    Err(e) => format!("Save failed: {}", e),
                                };
                            }
                        }
                    }
                    if ui.add_enabled(!self.undo.is_empty(), egui::Button::new("Undo")).clicked() {
                        if let Some(prev) = self.undo.pop() {
                            self.set_result(ctx, prev);
                            self.center = Center::Image;
                        }
                    }
                });
                ui.horizontal_wrapped(|ui| {
                    if ui.selectable_label(self.center == Center::Image, "Image").clicked() {
                        self.center = Center::Image;
                    }
                    if ui.selectable_label(self.center == Center::Text, "Text").clicked() {
                        self.center = Center::Text;
                    }
                    if ui.selectable_label(self.center == Center::Analysis, "Vision").clicked() {
                        self.center = Center::Analysis;
                    }
                });
                ui.separator();

                egui::CollapsingHeader::new("OCR text").default_open(true).show(ui, |ui| {
                    if ui.add_enabled(!self.ocr_busy, egui::Button::new("Read text from image")).clicked() {
                        self.center = Center::Text;
                        self.start_ocr(ctx);
                    }
                    ui.label(RichText::new("Works offline (Windows built-in OCR).").small().weak());
                });

                egui::CollapsingHeader::new("Remove background").default_open(true).show(ui, |ui| {
                    ui.add(egui::Slider::new(&mut self.tol, 8.0..=140.0).text("tolerance"));
                    if ui.button("Remove background").clicked() {
                        if let Some(img) = self.result.clone() {
                            self.push_undo();
                            let out = imgops::remove_background(&img, self.tol);
                            self.set_result(ctx, out);
                            self.center = Center::Image;
                            self.store_prompt = true;
                            self.status = "Background removed (best on plain backgrounds).".into();
                        }
                    }
                });

                egui::CollapsingHeader::new("ID photo / layouts").show(ui, |ui| {
                    egui::ComboBox::from_label("Size").selected_text(if self.id_size == 1 { "1x1 inch" } else { "2x2 inch" }).show_ui(ui, |ui| {
                        ui.selectable_value(&mut self.id_size, 1, "1x1 inch");
                        ui.selectable_value(&mut self.id_size, 2, "2x2 inch");
                    });
                    let bgs = ["Keep original", "White", "Blue", "Red", "Light gray"];
                    egui::ComboBox::from_label("Background").selected_text(bgs[self.id_bg]).show_ui(ui, |ui| {
                        for (i, n) in bgs.iter().enumerate() {
                            ui.selectable_value(&mut self.id_bg, i, *n);
                        }
                    });
                    let outfits = ["No outfit", "Formal navy suit + tie", "Black blazer + white blouse"];
                    egui::ComboBox::from_label("Outfit").selected_text(outfits[self.id_outfit]).show_ui(ui, |ui| {
                        for (i, n) in outfits.iter().enumerate() {
                            ui.selectable_value(&mut self.id_outfit, i, *n);
                        }
                    });
                    ui.checkbox(&mut self.id_sheet, "Tile on a 4x6 print sheet");
                    if ui.button("Create").clicked() {
                        if let Some(img) = self.result.clone() {
                            self.push_undo();
                            let bg = [None, Some([255, 255, 255]), Some([30, 90, 190]), Some([200, 30, 40]), Some([225, 225, 225])][self.id_bg];
                            let outfit = [imgops::Outfit::None, imgops::Outfit::NavySuit, imgops::Outfit::BlackBlazer][self.id_outfit];
                            let out = imgops::make_id_photo(&img, &imgops::IdOpts { size_in: self.id_size, bg, outfit, sheet: self.id_sheet });
                            self.set_result(ctx, out);
                            self.center = Center::Image;
                            self.status = "Layout created. Tip: remove the background first, then pick a colour.".into();
                        }
                    }
                    ui.label(RichText::new("Outfit is a simple drawn overlay aligned to the bottom of the photo.").small().weak());
                });

                egui::CollapsingHeader::new("Export").default_open(true).show(ui, |ui| {
                    let base = || store::exports_dir().join(format!("export_{}", chrono::Local::now().format("%Y%m%d_%H%M%S")));
                    ui.horizontal_wrapped(|ui| {
                        if ui.button("PDF").clicked() {
                            self.do_export("pdf", base().with_extension("pdf"));
                        }
                        if ui.button("ZIP").clicked() {
                            self.do_export("zip", base().with_extension("zip"));
                        }
                        if ui.button("Word (.docx)").clicked() {
                            self.do_export("docx", base().with_extension("docx"));
                        }
                        if ui.button("Excel (.xlsx)").clicked() {
                            self.do_export("xlsx", base().with_extension("xlsx"));
                        }
                    });
                    ui.label(RichText::new("Word/Excel/ZIP include the OCR text if you read it first.").small().weak());
                });

                egui::CollapsingHeader::new("Print").show(ui, |ui| {
                    if ui.button("Print this image").clicked() {
                        self.print_result();
                    }
                });

                egui::CollapsingHeader::new("AI Vision").show(ui, |ui| {
                    if ui.button("Analyze image").clicked() {
                        if let Some(i) = &self.result {
                            self.analysis = Some(imgops::analyze(i));
                            self.center = Center::Analysis;
                        }
                    }
                    if ui.button("Search with Google Lens").clicked() {
                        if let Some(i) = &self.result {
                            let _ = sys::copy_image_to_clipboard(i);
                            let _ = open::that("https://lens.google.com/");
                            self.status = "Image copied. Press Ctrl+V on the Google Lens page.".into();
                        }
                    }
                });

                egui::CollapsingHeader::new("Send").show(ui, |ui| {
                    let p = self.temp_png("send");
                    self.send_panel(ui, p, true);
                });

                egui::CollapsingHeader::new("Cloud storage").default_open(true).show(ui, |ui| {
                    if ui.button("Save to storage (+clouds)").clicked() {
                        self.store_result();
                    }
                    if self.user.is_none() {
                        ui.label(RichText::new("Sign in on Home first.").small().weak());
                    }
                });
            });
        });

        egui::CentralPanel::default().show(ctx, |ui| match self.center {
            Center::Image => {
                if let Some(t) = self.result_tex.clone() {
                    show_image(ui, &t);
                }
            }
            Center::Text => {
                ui.horizontal(|ui| {
                    ui.heading("Text from image");
                    if self.ocr_busy {
                        ui.spinner();
                    }
                });
                ui.label(RichText::new("Highlight words with the mouse, then ask AI about the selection.").small().weak());
                let out = egui::ScrollArea::vertical().max_height(ui.available_height() - 120.0).show(ui, |ui| {
                    egui::TextEdit::multiline(&mut self.ocr_text).desired_width(f32::INFINITY).desired_rows(16).show(ui)
                });
                if let Some(range) = out.inner.cursor_range {
                    let r = range.as_sorted_char_range();
                    if r.end > r.start {
                        self.sel_text = self.ocr_text.chars().skip(r.start).take(r.end - r.start).collect();
                    }
                }
                ui.separator();
                ui.horizontal(|ui| {
                    ui.label("Prompt:");
                    ui.text_edit_singleline(&mut self.ask_prefix);
                });
                let has_sel = !self.sel_text.trim().is_empty();
                let target = if has_sel { self.sel_text.clone() } else { self.ocr_text.clone() };
                ui.label(if has_sel { format!("Selected: \"{}\"", short(&self.sel_text, 70)) } else { "No selection - will use all text".to_string() });
                ui.horizontal_wrapped(|ui| {
                    if ui.add_enabled(!target.trim().is_empty(), egui::Button::new("Ask Claude")).clicked() {
                        self.ask_ai("https://claude.ai/new?q=", &target);
                    }
                    if ui.add_enabled(!target.trim().is_empty(), egui::Button::new("Ask ChatGPT")).clicked() {
                        self.ask_ai("https://chatgpt.com/?q=", &target);
                    }
                    if ui.button("Copy text").clicked() {
                        sys::copy_text(&self.ocr_text);
                        self.status = "Text copied.".into();
                    }
                    if ui.button("Clear selection").clicked() {
                        self.sel_text.clear();
                    }
                });
            }
            Center::Analysis => {
                ui.heading("Image analysis (offline)");
                if let Some(a) = &self.analysis {
                    ui.label(format!("Size: {} x {} px   |   Aspect: {}", a.width, a.height, a.aspect));
                    ui.label(format!("Brightness: {:.0}%   |   Edge detail: {:.0}%   |   Transparent: {:.0}%", a.brightness * 100.0, a.edge_density * 100.0, a.transparent_pct));
                    ui.label(RichText::new(format!("Looks like: {}", a.kind)).strong());
                    ui.add_space(6.0);
                    ui.label("Dominant colours:");
                    ui.horizontal(|ui| {
                        for (c, share) in &a.colors {
                            ui.vertical(|ui| {
                                let (r, _) = ui.allocate_exact_size(vec2(56.0, 36.0), Sense::hover());
                                ui.painter().rect_filled(r, Rounding::same(4.0), Color32::from_rgb(c[0], c[1], c[2]));
                                ui.label(RichText::new(format!("#{:02X}{:02X}{:02X}", c[0], c[1], c[2])).small());
                                ui.label(RichText::new(format!("{:.0}%", share * 100.0)).small());
                            });
                        }
                    });
                } else {
                    ui.label("Click \"Analyze image\" in the side panel.");
                }
                ui.add_space(8.0);
                if !self.ocr_text.trim().is_empty() {
                    ui.label(format!("Text found: \"{}\"", short(&self.ocr_text, 200)));
                }
                ui.add_space(8.0);
                if ui.button("Identify with Google Lens (copies image)").clicked() {
                    if let Some(i) = &self.result {
                        let _ = sys::copy_image_to_clipboard(i);
                        let _ = open::that("https://lens.google.com/");
                        self.status = "Image copied. Press Ctrl+V on the Google Lens page.".into();
                    }
                }
            }
        });
    }

    fn ask_ai(&mut self, base: &str, text: &str) {
        let q = format!("{}\n\n{}", self.ask_prefix, text);
        let q: String = q.chars().take(1800).collect();
        sys::copy_text(&q);
        let _ = open::that(format!("{}{}", base, sys::url_encode(&q)));
        self.status = "Opened in your browser (the question is also copied to the clipboard).".into();
    }

    fn do_export(&mut self, kind: &str, path: PathBuf) {
        let Some(img) = self.result.clone() else { return };
        let r = match kind {
            "pdf" => export::save_pdf(&img, &path),
            "zip" => export::save_zip(&img, &self.ocr_text, &path),
            "docx" => export::save_docx(&img, &self.ocr_text, &path),
            "xlsx" => {
                if self.ocr_text.trim().is_empty() {
                    Err("Read the text (OCR) first, then export to Excel.".to_string())
                } else {
                    export::save_xlsx(&self.ocr_text, &path)
                }
            }
            _ => Err("unknown".into()),
        };
        match r {
            Ok(_) => {
                self.status = format!("Exported {}", path.display());
                sys::reveal(&path);
            }
            Err(e) => self.status = format!("Export failed: {}", e),
        }
    }
}

fn res_ok(status: &str) -> bool {
    status.starts_with("Zipped")
}

fn short(s: &str, n: usize) -> String {
    let t: String = s.chars().take(n).collect::<String>().replace('\n', " ");
    if s.chars().count() > n { format!("{}...", t) } else { t }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> RgbaImage {
        // blue background with a red square "subject"
        let mut img = RgbaImage::from_pixel(200, 240, image::Rgba([30, 90, 190, 255]));
        for y in 60..200 {
            for x in 50..150 {
                img.put_pixel(x, y, image::Rgba([200, 40, 40, 255]));
            }
        }
        img
    }

    #[test]
    fn remove_bg_works() {
        let out = imgops::remove_background(&sample(), 40.0);
        assert_eq!(out.get_pixel(2, 2)[3], 0, "corner should be transparent");
        assert_eq!(out.get_pixel(100, 120)[3], 255, "subject should stay opaque");
    }

    #[test]
    fn id_photo_and_sheet() {
        let o = imgops::IdOpts { size_in: 1, bg: Some([255, 255, 255]), outfit: imgops::Outfit::NavySuit, sheet: false };
        let p = imgops::make_id_photo(&sample(), &o);
        assert_eq!(p.dimensions(), (300, 300));
        let s = imgops::make_id_photo(&sample(), &imgops::IdOpts { sheet: true, ..o });
        assert_eq!(s.dimensions(), (1200, 1800));
        let p2 = imgops::make_id_photo(&sample(), &imgops::IdOpts { size_in: 2, sheet: true, ..o });
        assert_eq!(p2.dimensions(), (1200, 1800));
    }

    #[test]
    fn exports_are_valid_files() {
        let dir = std::env::temp_dir().join("tw_test");
        let _ = std::fs::create_dir_all(&dir);
        let img = sample();
        export::save_pdf(&img, &dir.join("a.pdf")).unwrap();
        assert!(std::fs::read(dir.join("a.pdf")).unwrap().starts_with(b"%PDF"));
        export::save_zip(&img, "hello\nworld", &dir.join("a.zip")).unwrap();
        export::save_docx(&img, "hello & <world>", &dir.join("a.docx")).unwrap();
        export::save_xlsx("Name  Qty\nApple  3", &dir.join("a.xlsx")).unwrap();
        for f in ["a.zip", "a.docx", "a.xlsx"] {
            let z = zip::ZipArchive::new(std::fs::File::open(dir.join(f)).unwrap()).unwrap();
            assert!(z.len() >= 3, "{}", f);
        }
        export::save_gif(vec![img.clone(), img.clone()], 125, &dir.join("a.gif")).unwrap();
        assert!(std::fs::read(dir.join("a.gif")).unwrap().starts_with(b"GIF8"));
        export::save_image(&img, &dir.join("a.jpg")).unwrap();
    }

    #[test]
    fn pdf_edit_and_merge() {
        let dir = std::env::temp_dir().join("tw_test");
        let _ = std::fs::create_dir_all(&dir);
        let img = sample();
        export::save_pdf(&img, &dir.join("one.pdf")).unwrap();
        export::save_pdf(&img, &dir.join("two.pdf")).unwrap();
        export::pdf_merge(&dir.join("one.pdf"), &dir.join("two.pdf"), &dir.join("merged.pdf")).unwrap();
        assert_eq!(export::pdf_page_count(&dir.join("merged.pdf")).unwrap(), 2);
        export::pdf_edit(&dir.join("merged.pdf"), &dir.join("cut.pdf"), &[2], 90).unwrap();
        assert_eq!(export::pdf_page_count(&dir.join("cut.pdf")).unwrap(), 1);
        assert_eq!(parse_pages("1-3, 5", 10), vec![1, 2, 3, 5]);
    }

    #[test]
    fn analysis_runs() {
        let a = imgops::analyze(&sample());
        assert_eq!(a.width, 200);
        assert!(!a.colors.is_empty());
    }

    #[test]
    fn accounts_and_storage() {
        let name = format!("t{}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos() % 1_000_000);
        store::register(&name, "pass1234").unwrap();
        assert!(store::register(&name, "x1234").is_err());
        assert!(store::login(&name, "wrong").is_err());
        store::login(&name, "pass1234").unwrap();
        let c = store::store_item(&name, "Image", "png", &[1, 2, 3]).unwrap();
        assert!(c >= 5);
        let p = store::profile(&name);
        assert_eq!(p.entries.len(), 1);
        assert_eq!(p.clouds, c);
    }
}
