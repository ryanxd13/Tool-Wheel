//! Pure image processing: background removal, ID-photo layouts, outfits, analysis.
use image::{imageops, imageops::FilterType, Rgba, RgbaImage};

fn dist(p: &Rgba<u8>, c: &[f32; 3]) -> f32 {
    let dr = p[0] as f32 - c[0];
    let dg = p[1] as f32 - c[1];
    let db = p[2] as f32 - c[2];
    (dr * dr + dg * dg + db * db).sqrt()
}

/// Colour-key background removal: flood-fills inwards from the borders over
/// pixels that are close to any corner colour. Works best on plain backgrounds.
pub fn remove_background(src: &RgbaImage, tol: f32) -> RgbaImage {
    let (w, h) = src.dimensions();
    if w < 4 || h < 4 {
        return src.clone();
    }
    let patch = (w.min(h) / 20).clamp(1, 8);
    let mut corners = [[0f32; 3]; 4];
    let origins = [(0, 0), (w - patch, 0), (0, h - patch), (w - patch, h - patch)];
    for (i, (ox, oy)) in origins.iter().enumerate() {
        let mut s = [0f32; 3];
        for y in 0..patch {
            for x in 0..patch {
                let p = src.get_pixel(ox + x, oy + y);
                for k in 0..3 {
                    s[k] += p[k] as f32;
                }
            }
        }
        let n = (patch * patch) as f32;
        corners[i] = [s[0] / n, s[1] / n, s[2] / n];
    }
    let min_d = |x: u32, y: u32| -> f32 {
        let p = src.get_pixel(x, y);
        corners.iter().map(|c| dist(p, c)).fold(f32::MAX, f32::min)
    };
    let mut bg = vec![false; (w * h) as usize];
    let mut stack: Vec<(u32, u32)> = Vec::new();
    let seed = |x: u32, y: u32, bg: &mut Vec<bool>, st: &mut Vec<(u32, u32)>| {
        let i = (y * w + x) as usize;
        if !bg[i] && min_d(x, y) <= tol {
            bg[i] = true;
            st.push((x, y));
        }
    };
    for x in 0..w {
        seed(x, 0, &mut bg, &mut stack);
        seed(x, h - 1, &mut bg, &mut stack);
    }
    for y in 0..h {
        seed(0, y, &mut bg, &mut stack);
        seed(w - 1, y, &mut bg, &mut stack);
    }
    while let Some((x, y)) = stack.pop() {
        let nb = [
            (x.wrapping_sub(1), y),
            (x + 1, y),
            (x, y.wrapping_sub(1)),
            (x, y + 1),
        ];
        for (nx, ny) in nb {
            if nx < w && ny < h {
                let i = (ny * w + nx) as usize;
                if !bg[i] && min_d(nx, ny) <= tol {
                    bg[i] = true;
                    stack.push((nx, ny));
                }
            }
        }
    }
    let mut out = src.clone();
    for y in 0..h {
        for x in 0..w {
            let i = (y * w + x) as usize;
            if bg[i] {
                out.get_pixel_mut(x, y)[3] = 0;
            } else {
                // feather pixels touching removed area
                let touches = [(x.wrapping_sub(1), y), (x + 1, y), (x, y.wrapping_sub(1)), (x, y + 1)]
                    .iter()
                    .any(|&(nx, ny)| nx < w && ny < h && bg[(ny * w + nx) as usize]);
                if touches {
                    let d = min_d(x, y);
                    let t = ((d - tol) / (tol * 0.7 + 1.0)).clamp(0.0, 1.0);
                    let p = out.get_pixel_mut(x, y);
                    p[3] = (p[3] as f32 * t) as u8;
                }
            }
        }
    }
    out
}

pub fn crop(img: &RgbaImage, x: u32, y: u32, w: u32, h: u32) -> RgbaImage {
    let x = x.min(img.width().saturating_sub(1));
    let y = y.min(img.height().saturating_sub(1));
    let w = w.min(img.width() - x).max(1);
    let h = h.min(img.height() - y).max(1);
    imageops::crop_imm(img, x, y, w, h).to_image()
}

pub fn flatten(img: &RgbaImage, bg: [u8; 3]) -> RgbaImage {
    let mut out = RgbaImage::from_pixel(img.width(), img.height(), Rgba([bg[0], bg[1], bg[2], 255]));
    imageops::overlay(&mut out, img, 0, 0);
    out
}

// ---------- ID photos ----------

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Outfit {
    None,
    NavySuit,
    BlackBlazer,
}

#[derive(Clone, Copy)]
pub struct IdOpts {
    pub size_in: u32,
    pub bg: Option<[u8; 3]>,
    pub outfit: Outfit,
    pub sheet: bool,
}

fn fill_poly(img: &mut RgbaImage, pts: &[(f32, f32)], color: [u8; 3]) {
    let (w, h) = img.dimensions();
    let minx = pts.iter().map(|p| p.0).fold(f32::MAX, f32::min).max(0.0) as u32;
    let maxx = (pts.iter().map(|p| p.0).fold(f32::MIN, f32::max).ceil() as u32).min(w.saturating_sub(1));
    let miny = pts.iter().map(|p| p.1).fold(f32::MAX, f32::min).max(0.0) as u32;
    let maxy = (pts.iter().map(|p| p.1).fold(f32::MIN, f32::max).ceil() as u32).min(h.saturating_sub(1));
    for y in miny..=maxy {
        for x in minx..=maxx {
            let (px, py) = (x as f32 + 0.5, y as f32 + 0.5);
            let mut inside = false;
            let mut j = pts.len() - 1;
            for i in 0..pts.len() {
                let (xi, yi) = pts[i];
                let (xj, yj) = pts[j];
                if (yi > py) != (yj > py) && px < (xj - xi) * (py - yi) / (yj - yi) + xi {
                    inside = !inside;
                }
                j = i;
            }
            if inside {
                *img.get_pixel_mut(x, y) = Rgba([color[0], color[1], color[2], 255]);
            }
        }
    }
}

fn draw_outfit(img: &mut RgbaImage, outfit: Outfit) {
    let s = img.width() as f32;
    let sc = |v: &[(f32, f32)]| -> Vec<(f32, f32)> { v.iter().map(|(x, y)| (x * s, y * s)).collect() };
    match outfit {
        Outfit::None => {}
        Outfit::NavySuit => {
            fill_poly(img, &sc(&[(0.04, 1.0), (0.10, 0.84), (0.28, 0.74), (0.72, 0.74), (0.90, 0.84), (0.96, 1.0)]), [24, 36, 82]);
            fill_poly(img, &sc(&[(0.39, 0.74), (0.61, 0.74), (0.5, 0.97)]), [245, 245, 245]);
            fill_poly(img, &sc(&[(0.39, 0.74), (0.47, 0.76), (0.50, 0.93), (0.36, 0.80)]), [16, 26, 62]);
            fill_poly(img, &sc(&[(0.61, 0.74), (0.53, 0.76), (0.50, 0.93), (0.64, 0.80)]), [16, 26, 62]);
            fill_poly(img, &sc(&[(0.475, 0.77), (0.525, 0.77), (0.54, 0.85), (0.5, 1.0), (0.46, 0.85)]), [150, 20, 30]);
        }
        Outfit::BlackBlazer => {
            fill_poly(img, &sc(&[(0.04, 1.0), (0.10, 0.84), (0.28, 0.74), (0.72, 0.74), (0.90, 0.84), (0.96, 1.0)]), [25, 25, 28]);
            fill_poly(img, &sc(&[(0.36, 0.74), (0.64, 0.74), (0.5, 1.0)]), [250, 250, 250]);
            fill_poly(img, &sc(&[(0.36, 0.74), (0.45, 0.76), (0.50, 0.96), (0.33, 0.82)]), [12, 12, 14]);
            fill_poly(img, &sc(&[(0.64, 0.74), (0.55, 0.76), (0.50, 0.96), (0.67, 0.82)]), [12, 12, 14]);
        }
    }
}

pub fn make_id_photo(src: &RgbaImage, o: &IdOpts) -> RgbaImage {
    let (w, h) = src.dimensions();
    let side = w.min(h);
    let x = (w - side) / 2;
    let y = if h > w { (h - side) / 6 } else { 0 };
    let sq = imageops::crop_imm(src, x, y, side, side).to_image();
    let px = o.size_in * 300;
    let mut photo = imageops::resize(&sq, px, px, FilterType::Lanczos3);
    photo = flatten(&photo, o.bg.unwrap_or([255, 255, 255]));
    if o.bg.is_none() {
        // keep transparency when no background chosen and not tiling
        if !o.sheet {
            photo = imageops::resize(&sq, px, px, FilterType::Lanczos3);
        }
    }
    draw_outfit(&mut photo, o.outfit);
    if !o.sheet {
        return photo;
    }
    let (sw, sh) = (1200u32, 1800u32);
    let mut sheet = RgbaImage::from_pixel(sw, sh, Rgba([255, 255, 255, 255]));
    let cols = sw / px;
    let rows = sh / px;
    let ox = (sw - cols * px) / 2;
    let oy = (sh - rows * px) / 2;
    for r in 0..rows {
        for c in 0..cols {
            imageops::overlay(&mut sheet, &photo, (ox + c * px) as i64, (oy + r * px) as i64);
        }
    }
    // thin cutting guides
    let guide = Rgba([200, 200, 200, 255]);
    for c in 0..=cols {
        let gx = (ox + c * px).min(sw - 1);
        for yy in oy..(oy + rows * px).min(sh) {
            sheet.put_pixel(gx, yy, guide);
        }
    }
    for r in 0..=rows {
        let gy = (oy + r * px).min(sh - 1);
        for xx in ox..(ox + cols * px).min(sw) {
            sheet.put_pixel(xx, gy, guide);
        }
    }
    sheet
}

// ---------- offline "vision" analysis ----------

pub struct Analysis {
    pub width: u32,
    pub height: u32,
    pub aspect: String,
    pub brightness: f32,
    pub colors: Vec<([u8; 3], f32)>,
    pub edge_density: f32,
    pub kind: String,
    pub transparent_pct: f32,
}

pub fn analyze(img: &RgbaImage) -> Analysis {
    let (w, h) = img.dimensions();
    let step = ((w * h) as f32 / 40_000.0).sqrt().max(1.0) as u32;
    let mut hist = std::collections::HashMap::<u16, u32>::new();
    let mut total = 0u32;
    let mut bright = 0f64;
    let mut transp = 0u32;
    let mut edges = 0u32;
    let mut etotal = 0u32;
    let lum = |p: &Rgba<u8>| 0.299 * p[0] as f32 + 0.587 * p[1] as f32 + 0.114 * p[2] as f32;
    let mut y = 0;
    while y < h {
        let mut x = 0;
        while x < w {
            let p = img.get_pixel(x, y);
            if p[3] < 20 {
                transp += 1;
            } else {
                let key = ((p[0] >> 4) as u16) << 8 | ((p[1] >> 4) as u16) << 4 | (p[2] >> 4) as u16;
                *hist.entry(key).or_insert(0) += 1;
                bright += lum(p) as f64;
                total += 1;
            }
            if x + step < w && y + step < h {
                let a = lum(p);
                let b = lum(img.get_pixel(x + step, y));
                let c = lum(img.get_pixel(x, y + step));
                if (a - b).abs() + (a - c).abs() > 40.0 {
                    edges += 1;
                }
                etotal += 1;
            }
            x += step;
        }
        y += step;
    }
    let mut v: Vec<(u16, u32)> = hist.into_iter().collect();
    v.sort_by(|a, b| b.1.cmp(&a.1));
    let t = total.max(1) as f32;
    let colors: Vec<([u8; 3], f32)> = v
        .iter()
        .take(5)
        .map(|(k, c)| ([((k >> 8) as u8) * 16 + 8, (((k >> 4) & 15) as u8) * 16 + 8, ((k & 15) as u8) * 16 + 8], *c as f32 / t))
        .collect();
    let rich = v.iter().filter(|(_, c)| *c as f32 / t > 0.001).count();
    let edge_density = edges as f32 / etotal.max(1) as f32;
    let top_share = colors.first().map(|c| c.1).unwrap_or(0.0);
    let kind = if transp as f32 / (total + transp).max(1) as f32 > 0.2 {
        "Cut-out / sticker-like image (large transparent area)"
    } else if rich > 180 && edge_density < 0.25 {
        "Photo-like image (many smooth colour gradients)"
    } else if top_share > 0.45 && edge_density > 0.04 {
        "Screenshot / document / text-heavy image"
    } else {
        "Graphic, UI or illustration"
    };
    let g = gcd(w, h).max(1);
    Analysis {
        width: w,
        height: h,
        aspect: format!("{}:{}", w / g, h / g),
        brightness: (bright / total.max(1) as f64 / 255.0) as f32,
        colors,
        edge_density,
        kind: kind.to_string(),
        transparent_pct: transp as f32 / (total + transp).max(1) as f32 * 100.0,
    }
}

fn gcd(a: u32, b: u32) -> u32 {
    if b == 0 { a } else { gcd(b, a % b) }
}
