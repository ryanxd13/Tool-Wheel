//! Exporters: PNG/JPG, PDF, ZIP, DOCX, XLSX, GIF — all written locally, no external tools.
use crate::imgops;
use image::RgbaImage;
use std::io::{Cursor, Write};
use std::path::Path;
use zip::write::FileOptions;

pub fn png_bytes(img: &RgbaImage) -> Vec<u8> {
    let mut buf = Cursor::new(Vec::new());
    let _ = img.write_to(&mut buf, image::ImageFormat::Png);
    buf.into_inner()
}

pub fn save_image(img: &RgbaImage, path: &Path) -> Result<(), String> {
    let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("png").to_lowercase();
    if ext == "jpg" || ext == "jpeg" {
        let flat = imgops::flatten(img, [255, 255, 255]);
        image::DynamicImage::ImageRgba8(flat).to_rgb8().save(path).map_err(|e| e.to_string())
    } else {
        img.save(path).map_err(|e| e.to_string())
    }
}

pub fn save_pdf(img: &RgbaImage, path: &Path) -> Result<(), String> {
    use printpdf::*;
    let flat = imgops::flatten(img, [255, 255, 255]);
    let (w, h) = flat.dimensions();
    let dpi = 150.0_f32;
    let wmm = w as f32 * 25.4 / dpi;
    let hmm = h as f32 * 25.4 / dpi;
    let (doc, page, layer) = PdfDocument::new("ToolWheel Export", Mm(wmm), Mm(hmm), "Layer 1");
    let rgb = printpdf::image_crate::RgbImage::from_raw(w, h, flat.pixels().flat_map(|p| [p[0], p[1], p[2]]).collect())
        .ok_or("bad image buffer")?;
    let dynimg = printpdf::image_crate::DynamicImage::ImageRgb8(rgb);
    let image = Image::from_dynamic_image(&dynimg);
    let layer = doc.get_page(page).get_layer(layer);
    image.add_to_layer(layer, ImageTransform { dpi: Some(dpi), ..Default::default() });
    let file = std::fs::File::create(path).map_err(|e| e.to_string())?;
    doc.save(&mut std::io::BufWriter::new(file)).map_err(|e| e.to_string())
}

pub fn save_zip(img: &RgbaImage, text: &str, path: &Path) -> Result<(), String> {
    let file = std::fs::File::create(path).map_err(|e| e.to_string())?;
    let mut z = zip::ZipWriter::new(file);
    let opt = FileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    z.start_file("image.png", opt).map_err(|e| e.to_string())?;
    z.write_all(&png_bytes(img)).map_err(|e| e.to_string())?;
    let flat = imgops::flatten(img, [255, 255, 255]);
    let mut jpg = Cursor::new(Vec::new());
    image::DynamicImage::ImageRgba8(flat)
        .to_rgb8()
        .write_to(&mut jpg, image::ImageFormat::Jpeg)
        .map_err(|e| e.to_string())?;
    z.start_file("image.jpg", opt).map_err(|e| e.to_string())?;
    z.write_all(&jpg.into_inner()).map_err(|e| e.to_string())?;
    if !text.trim().is_empty() {
        z.start_file("text.txt", opt).map_err(|e| e.to_string())?;
        z.write_all(text.as_bytes()).map_err(|e| e.to_string())?;
    }
    z.finish().map_err(|e| e.to_string())?;
    Ok(())
}

fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

pub fn save_docx(img: &RgbaImage, text: &str, path: &Path) -> Result<(), String> {
    let file = std::fs::File::create(path).map_err(|e| e.to_string())?;
    let mut z = zip::ZipWriter::new(file);
    let opt = FileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    let mut put = |name: &str, data: &[u8]| -> Result<(), String> {
        z.start_file(name, opt).map_err(|e| e.to_string())?;
        z.write_all(data).map_err(|e| e.to_string())
    };
    put("[Content_Types].xml", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>"#)?;
    put("_rels/.rels", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>"#)?;
    put("word/_rels/document.xml.rels", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image1.png"/></Relationships>"#)?;
    let (w, h) = img.dimensions();
    let cx = 5_486_400u64; // 6 inches in EMU
    let cy = cx * h as u64 / w.max(1) as u64;
    let mut body = String::new();
    body.push_str(&format!(
        r#"<w:p><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="1" name="Picture 1"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="image1.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rId1"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>"#
    ));
    for line in text.lines() {
        body.push_str(&format!(r#"<w:p><w:r><w:t xml:space="preserve">{}</w:t></w:r></w:p>"#, esc(line)));
    }
    let doc = format!(
        r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"><w:body>{body}</w:body></w:document>"#
    );
    put("word/document.xml", doc.as_bytes())?;
    put("word/media/image1.png", &png_bytes(img))?;
    z.finish().map_err(|e| e.to_string())?;
    Ok(())
}

pub fn save_xlsx(text: &str, path: &Path) -> Result<(), String> {
    let file = std::fs::File::create(path).map_err(|e| e.to_string())?;
    let mut z = zip::ZipWriter::new(file);
    let opt = FileOptions::default().compression_method(zip::CompressionMethod::Deflated);
    let mut put = |name: &str, data: &[u8]| -> Result<(), String> {
        z.start_file(name, opt).map_err(|e| e.to_string())?;
        z.write_all(data).map_err(|e| e.to_string())
    };
    put("[Content_Types].xml", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>"#)?;
    put("_rels/.rels", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"#)?;
    put("xl/workbook.xml", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="OCR" sheetId="1" r:id="rId1"/></sheets></workbook>"#)?;
    put("xl/_rels/workbook.xml.rels", br#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>"#)?;
    let mut rows = String::new();
    for (ri, line) in text.lines().enumerate() {
        rows.push_str(&format!(r#"<row r="{}">"#, ri + 1));
        // split into columns on tabs or runs of 2+ spaces
        let cells: Vec<String> = line
            .replace('\t', "  ")
            .split("  ")
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty())
            .collect();
        let cells = if cells.is_empty() { vec![String::new()] } else { cells };
        for (ci, c) in cells.iter().take(26).enumerate() {
            let col = (b'A' + ci as u8) as char;
            rows.push_str(&format!(r#"<c r="{}{}" t="inlineStr"><is><t xml:space="preserve">{}</t></is></c>"#, col, ri + 1, esc(c)));
        }
        rows.push_str("</row>");
    }
    let sheet = format!(
        r#"<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{rows}</sheetData></worksheet>"#
    );
    put("xl/worksheets/sheet1.xml", sheet.as_bytes())?;
    z.finish().map_err(|e| e.to_string())?;
    Ok(())
}

pub fn save_gif(frames: Vec<RgbaImage>, delay_ms: u32, path: &Path) -> Result<(), String> {
    use image::codecs::gif::{GifEncoder, Repeat};
    use image::{Delay, Frame};
    let file = std::fs::File::create(path).map_err(|e| e.to_string())?;
    let mut enc = GifEncoder::new_with_speed(std::io::BufWriter::new(file), 20);
    enc.set_repeat(Repeat::Infinite).map_err(|e| e.to_string())?;
    for f in frames {
        let frame = Frame::from_parts(f, 0, 0, Delay::from_numer_denom_ms(delay_ms, 1));
        enc.encode_frame(frame).map_err(|e| e.to_string())?;
    }
    Ok(())
}

// ---------- PDF editing (lopdf) ----------

pub fn pdf_page_count(path: &Path) -> Result<usize, String> {
    let doc = lopdf::Document::load(path).map_err(|e| e.to_string())?;
    Ok(doc.get_pages().len())
}

/// keep: 1-based page numbers to keep (in original order). rotate: degrees added to every kept page.
pub fn pdf_edit(input: &Path, output: &Path, keep: &[u32], rotate: i64) -> Result<(), String> {
    let mut doc = lopdf::Document::load(input).map_err(|e| e.to_string())?;
    let pages = doc.get_pages();
    let all: Vec<u32> = pages.keys().copied().collect();
    let remove: Vec<u32> = all.iter().copied().filter(|p| !keep.contains(p)).collect();
    if remove.len() == all.len() {
        return Err("You must keep at least one page".into());
    }
    if rotate != 0 {
        for p in &all {
            if !keep.contains(p) {
                continue;
            }
            if let Some(id) = pages.get(p) {
                if let Ok(obj) = doc.get_object_mut(*id) {
                    if let Ok(dict) = obj.as_dict_mut() {
                        let cur = dict.get(b"Rotate").and_then(|o| o.as_i64()).unwrap_or(0);
                        dict.set("Rotate", ((cur + rotate) % 360 + 360) % 360);
                    }
                }
            }
        }
    }
    doc.delete_pages(&remove);
    doc.prune_objects();
    doc.save(output).map_err(|e| e.to_string())?;
    Ok(())
}

/// Append all pages of `other` to `base` and save to `output`.
pub fn pdf_merge(base: &Path, other: &Path, output: &Path) -> Result<(), String> {
    use lopdf::{Document, Object, ObjectId};
    use std::collections::BTreeMap;
    let docs = [Document::load(base).map_err(|e| e.to_string())?, Document::load(other).map_err(|e| e.to_string())?];
    let mut max_id = 1;
    let mut pages: BTreeMap<ObjectId, Object> = BTreeMap::new();
    let mut objects: BTreeMap<ObjectId, Object> = BTreeMap::new();
    let mut merged = Document::with_version("1.5");
    for mut doc in docs {
        doc.renumber_objects_with(max_id);
        max_id = doc.max_id + 1;
        for (_, oid) in doc.get_pages() {
            if let Ok(o) = doc.get_object(oid) {
                pages.insert(oid, o.clone());
            }
        }
        objects.extend(doc.objects);
    }
    let mut catalog: Option<(ObjectId, Object)> = None;
    let mut pages_root: Option<(ObjectId, Object)> = None;
    for (oid, obj) in objects.iter() {
        match obj.type_name().unwrap_or("") {
            "Catalog" => catalog = Some((catalog.map(|c| c.0).unwrap_or(*oid), obj.clone())),
            "Pages" => {
                if let Ok(d) = obj.as_dict() {
                    let mut d = d.clone();
                    if let Some((_, ref old)) = pages_root {
                        if let Ok(od) = old.as_dict() {
                            d.extend(od);
                        }
                    }
                    pages_root = Some((pages_root.map(|p| p.0).unwrap_or(*oid), Object::Dictionary(d)));
                }
            }
            "Page" | "Outlines" | "Outline" => {}
            _ => {
                merged.objects.insert(*oid, obj.clone());
            }
        }
    }
    let (cat_id, cat_obj) = catalog.ok_or("PDF has no catalog")?;
    let (root_id, root_obj) = pages_root.ok_or("PDF has no pages root")?;
    for (oid, obj) in pages.iter() {
        if let Ok(d) = obj.as_dict() {
            let mut d = d.clone();
            d.set("Parent", root_id);
            merged.objects.insert(*oid, Object::Dictionary(d));
        }
    }
    if let Ok(d) = root_obj.as_dict() {
        let mut d = d.clone();
        d.set("Count", pages.len() as u32);
        d.set("Kids", pages.keys().map(|id| Object::Reference(*id)).collect::<Vec<_>>());
        merged.objects.insert(root_id, Object::Dictionary(d));
    }
    if let Ok(d) = cat_obj.as_dict() {
        let mut d = d.clone();
        d.set("Pages", root_id);
        d.remove(b"Outlines");
        merged.objects.insert(cat_id, Object::Dictionary(d));
    }
    merged.trailer.set("Root", cat_id);
    merged.max_id = merged.objects.len() as u32;
    merged.renumber_objects();
    merged.compress();
    merged.save(output).map_err(|e| e.to_string())?;
    Ok(())
}
