//! Local accounts + "cloud" storage + history. Everything lives in <Documents>/ToolWheel.
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::path::PathBuf;

#[derive(Serialize, Deserialize, Clone)]
struct User {
    name: String,
    salt: String,
    hash: String,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct Entry {
    pub id: u64,
    pub label: String,
    pub file: String,
    pub when: String,
    pub bytes: u64,
}

#[derive(Serialize, Deserialize, Default, Clone)]
pub struct Profile {
    pub clouds: u32,
    pub entries: Vec<Entry>,
}

pub fn base() -> PathBuf {
    let b = dirs::document_dir().or_else(dirs::home_dir).unwrap_or_else(|| PathBuf::from(".")).join("ToolWheel");
    let _ = std::fs::create_dir_all(&b);
    b
}

fn users_path() -> PathBuf {
    base().join("users.json")
}

fn hash(salt: &str, pw: &str) -> String {
    let mut h = Sha256::new();
    h.update(salt.as_bytes());
    h.update(pw.as_bytes());
    h.finalize().iter().map(|b| format!("{:02x}", b)).collect()
}

fn load_users() -> Vec<User> {
    std::fs::read_to_string(users_path()).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
}

fn user_dir(name: &str) -> PathBuf {
    let d = base().join("storage").join(name);
    let _ = std::fs::create_dir_all(&d);
    d
}

fn valid_name(n: &str) -> bool {
    !n.is_empty() && n.len() <= 24 && n.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-')
}

pub fn register(name: &str, pw: &str) -> Result<(), String> {
    if !valid_name(name) {
        return Err("Username: 1-24 letters, numbers, _ or -".into());
    }
    if pw.len() < 4 {
        return Err("Password must be at least 4 characters".into());
    }
    let mut users = load_users();
    if users.iter().any(|u| u.name.eq_ignore_ascii_case(name)) {
        return Err("Username already exists".into());
    }
    let nanos = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let salt = hash(&nanos.to_string(), name);
    users.push(User { name: name.to_string(), hash: hash(&salt, pw), salt });
    std::fs::write(users_path(), serde_json::to_string_pretty(&users).unwrap()).map_err(|e| e.to_string())
}

pub fn login(name: &str, pw: &str) -> Result<(), String> {
    let users = load_users();
    match users.iter().find(|u| u.name.eq_ignore_ascii_case(name)) {
        Some(u) if u.hash == hash(&u.salt, pw) => Ok(()),
        _ => Err("Wrong username or password".into()),
    }
}

pub fn profile(name: &str) -> Profile {
    std::fs::read_to_string(user_dir(name).join("profile.json")).ok().and_then(|s| serde_json::from_str(&s).ok()).unwrap_or_default()
}

fn save_profile(name: &str, p: &Profile) {
    let _ = std::fs::write(user_dir(name).join("profile.json"), serde_json::to_string_pretty(p).unwrap());
}

/// Stores bytes in the user's storage; returns clouds earned.
pub fn store_item(user: &str, label: &str, ext: &str, data: &[u8]) -> Result<u32, String> {
    let mut p = profile(user);
    let id = p.entries.iter().map(|e| e.id).max().unwrap_or(0) + 1;
    let file = format!("{}_{}.{}", id, chrono::Local::now().format("%Y%m%d_%H%M%S"), ext);
    std::fs::write(user_dir(user).join(&file), data).map_err(|e| e.to_string())?;
    let earned = 5 + (data.len() as u32 / 100_000).min(20);
    p.clouds += earned;
    p.entries.push(Entry {
        id,
        label: label.to_string(),
        file,
        when: chrono::Local::now().format("%Y-%m-%d %H:%M").to_string(),
        bytes: data.len() as u64,
    });
    save_profile(user, &p);
    Ok(earned)
}

pub fn entry_path(user: &str, e: &Entry) -> PathBuf {
    user_dir(user).join(&e.file)
}

pub fn delete_item(user: &str, id: u64) {
    let mut p = profile(user);
    if let Some(e) = p.entries.iter().find(|e| e.id == id).cloned() {
        let _ = std::fs::remove_file(entry_path(user, &e));
    }
    p.entries.retain(|e| e.id != id);
    save_profile(user, &p);
}

pub fn exports_dir() -> PathBuf {
    let d = base().join("exports");
    let _ = std::fs::create_dir_all(&d);
    d
}
