//! OS helpers: screen capture, OCR (offline), printing, opening apps/links.
use image::RgbaImage;
use std::path::{Path, PathBuf};
use std::process::Command;

#[cfg(windows)]
use std::os::windows::process::CommandExt;

pub struct Shot {
    pub img: RgbaImage,
    pub x: i32,
    pub y: i32,
}

fn hide(cmd: &mut Command) -> &mut Command {
    #[cfg(windows)]
    {
        cmd.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    }
    cmd
}

pub fn temp_path(name: &str) -> PathBuf {
    std::env::temp_dir().join(name)
}

/// Convert whatever image version xcap uses into our `image` version.
fn convert<I: Into<Vec<u8>>>(w: u32, h: u32, raw: I) -> Option<RgbaImage> {
    RgbaImage::from_raw(w, h, raw.into())
}

pub fn capture_primary() -> Result<Shot, String> {
    let monitors = xcap::Monitor::all().map_err(|e| e.to_string())?;
    let m = monitors
        .iter()
        .find(|m| m.is_primary().unwrap_or(false))
        .or_else(|| monitors.first())
        .ok_or("No monitor found")?;
    let cap = m.capture_image().map_err(|e| e.to_string())?;
    let (w, h) = (cap.width(), cap.height());
    let img = convert(w, h, cap.into_raw()).ok_or("Bad capture buffer")?;
    Ok(Shot { img, x: m.x().unwrap_or(0), y: m.y().unwrap_or(0) })
}

pub fn ocr_image(img: &RgbaImage) -> Result<String, String> {
    // Flatten alpha on white, upscale small crops (helps OCR accuracy).
    let mut flat = image::RgbaImage::from_pixel(img.width(), img.height(), image::Rgba([255, 255, 255, 255]));
    image::imageops::overlay(&mut flat, img, 0, 0);
    let flat = if flat.height() < 400 {
        image::imageops::resize(&flat, flat.width() * 2, flat.height() * 2, image::imageops::FilterType::CatmullRom)
    } else {
        flat
    };
    let path = temp_path("toolwheel_ocr_input.png");
    flat.save(&path).map_err(|e| e.to_string())?;

    #[cfg(windows)]
    {
        let script = temp_path("toolwheel_ocr.ps1");
        std::fs::write(&script, OCR_PS).map_err(|e| e.to_string())?;
        let mut c = Command::new("powershell");
        c.args(["-NoProfile", "-ExecutionPolicy", "Bypass", "-File"]).arg(&script).arg(&path);
        hide(&mut c);
        let out = c.output().map_err(|e| e.to_string())?;
        let text = String::from_utf8_lossy(&out.stdout).trim().to_string();
        if text.is_empty() {
            let err = String::from_utf8_lossy(&out.stderr).trim().to_string();
            if err.is_empty() { Ok(String::new()) } else { Err(err) }
        } else {
            Ok(text)
        }
    }
    #[cfg(not(windows))]
    {
        let out = Command::new("tesseract")
            .arg(&path)
            .arg("stdout")
            .output()
            .map_err(|_| "OCR on this OS needs 'tesseract' installed (Windows uses built-in OCR).".to_string())?;
        Ok(String::from_utf8_lossy(&out.stdout).trim().to_string())
    }
}

#[cfg(windows)]
const OCR_PS: &str = r#"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
Function Await($WinRtTask, $ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $netTask = $asTask.Invoke($null, @($WinRtTask))
  $netTask.Wait(-1) | Out-Null
  $netTask.Result
}
$path = $args[0]
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
$result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
$result.Text
"#;

pub fn print_file(path: &Path) -> Result<(), String> {
    #[cfg(windows)]
    {
        let p = path.to_string_lossy().replace('\'', "''");
        let mut c = Command::new("powershell");
        c.args(["-NoProfile", "-Command", &format!("Start-Process -FilePath '{}' -Verb Print", p)]);
        hide(&mut c);
        match c.status() {
            Ok(s) if s.success() => Ok(()),
            _ => open::that(path).map_err(|e| e.to_string()),
        }
    }
    #[cfg(not(windows))]
    {
        match Command::new("lp").arg(path).status() {
            Ok(s) if s.success() => Ok(()),
            _ => open::that(path).map_err(|e| e.to_string()),
        }
    }
}

pub fn reveal(path: &Path) {
    #[cfg(windows)]
    {
        let _ = Command::new("explorer").arg(format!("/select,{}", path.display())).spawn();
    }
    #[cfg(not(windows))]
    {
        if let Some(p) = path.parent() {
            let _ = open::that(p);
        }
    }
}

pub fn url_encode(s: &str) -> String {
    let mut o = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => o.push(b as char),
            _ => o.push_str(&format!("%{:02X}", b)),
        }
    }
    o
}

pub fn copy_image_to_clipboard(img: &RgbaImage) -> Result<(), String> {
    let mut cb = arboard::Clipboard::new().map_err(|e| e.to_string())?;
    cb.set_image(arboard::ImageData {
        width: img.width() as usize,
        height: img.height() as usize,
        bytes: std::borrow::Cow::Borrowed(img.as_raw()),
    })
    .map_err(|e| e.to_string())
}

pub fn copy_text(s: &str) {
    if let Ok(mut cb) = arboard::Clipboard::new() {
        let _ = cb.set_text(s.to_string());
    }
}
